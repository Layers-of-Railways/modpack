// priority: 0
ServerEvents.recipes((event) => {});
