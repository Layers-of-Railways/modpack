// let convert = [
// 	["minecraft:sand", "minecraft:dirt"]
// ];

// ServerEvents.recipes((event) => {
//   convert.forEach((recipeMap) => {
//     event.shapeless(Item.of(recipeMap[1]), [recipeMap[0]]);
//     event.shapeless(Item.of(recipeMap[0]), [recipeMap[1]]);
//   });
// });
