ServerEvents.tags("fluid", (event) => {
    // Bottomless Honey
    event.add("create:bottomless/allow", "create:honey");
});
